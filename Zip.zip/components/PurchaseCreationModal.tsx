"use client";

import React, { useState, useMemo, useEffect } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, Trash2, ClipboardList, FileMinus, ShoppingBag, Phone, UserCheck, UserPlus, X, 
  AlertCircle, CheckCircle2, ChevronDown, ChevronUp, Barcode, ShieldAlert, Sparkles, ArrowRight
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

function formatCurrency(val: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(val);
}

interface PurchaseCreationModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode?: "entry" | "debit-note" | "order";
}

export function PurchaseCreationModal({ isOpen, onClose, mode = "entry" }: PurchaseCreationModalProps) {
  const queryClient = useQueryClient();
  const [currentMode, setCurrentMode] = useState<"entry" | "debit-note" | "order">(mode);

  // Sync mode prop with local state when modal opens
  useEffect(() => {
    if (isOpen) {
      setCurrentMode(mode);
    }
  }, [isOpen, mode]);

  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers"],
    queryFn: async () => {
      const res = await fetch("/api/suppliers");
      const json = await res.json();
      return json.success ? json.data : [];
    }
  });

  const { data: catalogItems = [] } = useQuery({
    queryKey: ["items"],
    queryFn: async () => {
      const res = await fetch("/api/items");
      const json = await res.json();
      return json.success ? json.data : [];
    }
  });

  const { data: purchaseEntries = [] } = useQuery({
    queryKey: ["purchase-entries"],
    queryFn: async () => {
      const res = await fetch("/api/purchase-entries");
      const json = await res.json();
      return json.success ? json.data : [];
    }
  });

  const { data: purchaseOrders = [] } = useQuery({
    queryKey: ["purchase-orders"],
    queryFn: async () => {
      const res = await fetch("/api/purchase-orders");
      const json = await res.json();
      return json.success ? json.data : [];
    }
  });

  const [form, setForm] = useState({
    billNo: "",
    billDate: new Date().toISOString().split("T")[0],
    supplierName: "",
    supplierPhone: "",
    supplierId: "" as string,
    linkedPoNo: "",
    items: [] as Array<{
      id: string;
      itemId: string;
      name: string;
      quantity: number;
      rate: number;
      gstRate: number;
      serialNumbers: string[];
      showSerials?: boolean;
    }>,
  });

  const [supplierLookupStatus, setSupplierLookupStatus] = useState<"idle" | "existing" | "new">("idle");

  // Get active pending POs for the selected supplier
  const supplierPendingPOs = useMemo(() => {
    if (!form.supplierName) return [];
    return purchaseOrders.filter((po: any) => 
      po.supplierName?.trim().toLowerCase() === form.supplierName.trim().toLowerCase() && 
      po.status !== "received"
    );
  }, [purchaseOrders, form.supplierName]);

  const handleSupplierPhoneLookup = (phone: string) => {
    const cleanPhone = phone.replace(/\D/g, '');
    setForm((prev) => ({ ...prev, supplierPhone: cleanPhone }));

    if (cleanPhone.length < 10) {
      setSupplierLookupStatus("idle");
      return;
    }

    if (cleanPhone.length === 10) {
      const found = suppliers.find((s: any) => s.phone === cleanPhone);
      if (found) {
        setForm((prev) => ({
          ...prev,
          supplierId: found._id,
          supplierName: found.name,
          supplierPhone: cleanPhone,
          linkedPoNo: "",
          items: [],
        }));
        setSupplierLookupStatus("existing");
        toast.success(`Supplier found: ${found.name}`);
      } else {
        setForm((prev) => ({
          ...prev,
          supplierId: "new",
          supplierName: "",
          supplierPhone: cleanPhone,
          linkedPoNo: "",
          items: [],
        }));
        setSupplierLookupStatus("new");
      }
    }
  };

  const handleSupplierSelect = (supplierName: string) => {
    const found = suppliers.find((s: any) => s.name === supplierName);
    if (found) {
      setForm(prev => ({
        ...prev,
        supplierName: found.name,
        supplierPhone: found.phone || "",
        supplierId: found._id,
        linkedPoNo: "",
        items: [],
      }));
      setSupplierLookupStatus("existing");
    }
  };

  const handleLoadPO = (poNo: string) => {
    const po = purchaseOrders.find((p: any) => p.poNo === poNo);
    if (!po) return;
    
    setForm(prev => ({
      ...prev,
      supplierName: po.supplierName,
      linkedPoNo: poNo,
      items: (po.items || []).map((i: any) => {
        const qty = Number(i.quantity) || 1;
        return {
          id: Math.random().toString(),
          itemId: i.itemId,
          name: i.name,
          quantity: qty,
          rate: Number(i.rate) || 0,
          gstRate: Number(i.gstRate) || 18,
          serialNumbers: Array.from({ length: qty }).map(() => ""),
          showSerials: true,
        };
      })
    }));
    toast.success(`Loaded items from Purchase Order ${poNo}`);
  };

  useEffect(() => {
    if (isOpen) {
      setForm(prev => {
        let newNo = "";
        if (currentMode === "order") {
          const numbers = purchaseOrders.map((p: any) => {
            const matches = (p.poNo || "").match(/\d+/g);
            return matches ? parseInt(matches[matches.length - 1], 10) : 0;
          });
          const maxNum = numbers.length ? Math.max(...numbers, 0) : 0;
          newNo = `PO-2026-${String(maxNum + 1).padStart(4, "0")}`;
        } else {
          const entriesOfMode = purchaseEntries.filter((x: any) => x.type === currentMode);
          const numbers = entriesOfMode.map((e: any) => {
            const matches = (e.billNo || "").match(/\d+/g);
            return matches ? parseInt(matches[matches.length - 1], 10) : 0;
          });
          const maxNum = numbers.length ? Math.max(...numbers, 0) : 0;
          if (currentMode === "debit-note") {
            newNo = `DN-2026-${String(maxNum + 1).padStart(4, "0")}`;
          } else {
            newNo = `BILL-2026-${String(maxNum + 1).padStart(4, "0")}`;
          }
        }
        return { ...prev, billNo: newNo };
      });
    }
  }, [isOpen, currentMode, purchaseEntries, purchaseOrders]);

  const addLineItem = () => {
    setForm(prev => ({
      ...prev,
      items: [
        ...prev.items,
        {
          id: Math.random().toString(),
          itemId: "",
          name: "",
          quantity: 1,
          rate: 0,
          gstRate: 18,
          serialNumbers: [""],
          showSerials: true,
        }
      ]
    }));
  };

  const removeLineItem = (id: string) => {
    setForm(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== id)
    }));
  };

  const handleItemSelect = (rowId: string, itemId: string) => {
    const catalogItem = catalogItems.find((i: any) => i._id === itemId);
    if (!catalogItem) return;

    setForm(prev => ({
      ...prev,
      items: prev.items.map(item =>
        item.id === rowId
          ? {
              ...item,
              itemId: catalogItem._id,
              name: catalogItem.name,
              rate: catalogItem.purchasePrice || 0,
              gstRate: catalogItem.gstRate || 18,
            }
          : item
      )
    }));
  };

  const updateLineItem = (rowId: string, field: string, value: any) => {
    setForm(prev => ({
      ...prev,
      items: prev.items.map(item => {
        if (item.id !== rowId) return item;

        if (field === "quantity") {
          const newQty = Math.max(1, Number(value));
          const currentSerials = item.serialNumbers || [];
          let updatedSerials: string[] = [];
          if (newQty > currentSerials.length) {
            updatedSerials = [
              ...currentSerials,
              ...Array.from({ length: newQty - currentSerials.length }).map(() => "")
            ];
          } else {
            updatedSerials = currentSerials.slice(0, newQty);
          }
          return { ...item, quantity: newQty, serialNumbers: updatedSerials };
        }

        return { ...item, [field]: value };
      })
    }));
  };

  const updateSerialNumber = (rowId: string, unitIndex: number, serialValue: string) => {
    setForm(prev => ({
      ...prev,
      items: prev.items.map(item => {
        if (item.id !== rowId) return item;
        const serials = [...(item.serialNumbers || [])];
        serials[unitIndex] = serialValue;
        return { ...item, serialNumbers: serials };
      })
    }));
  };

  const toggleSerialsDisplay = (rowId: string) => {
    setForm(prev => ({
      ...prev,
      items: prev.items.map(item =>
        item.id === rowId ? { ...item, showSerials: !item.showSerials } : item
      )
    }));
  };

  const totals = useMemo(() => {
    let subtotal = 0;
    let gst = 0;

    form.items.forEach(item => {
      const rowTotal = (item.quantity || 0) * (item.rate || 0);
      const rowGst = rowTotal * ((item.gstRate || 0) / 100);
      subtotal += rowTotal;
      gst += rowGst;
    });

    return {
      subtotal,
      gst,
      total: subtotal + gst,
    };
  }, [form.items]);

  const saveMutation = useMutation({
    networkMode: "always",
    mutationFn: async () => {
      const payload: any = {
        type: currentMode,
        billNo: form.billNo,
        supplierName: form.supplierName,
        supplierPhone: form.supplierPhone,
        supplierId: form.supplierId,
        billDate: form.billDate,
        linkedPoNo: form.linkedPoNo,
        items: form.items.map(i => ({
          itemId: i.itemId,
          name: i.name,
          quantity: Number(i.quantity),
          rate: Number(i.rate),
          gstRate: Number(i.gstRate),
          serialNumbers: i.serialNumbers || [],
        })),
        subtotal: totals.subtotal,
        gst: totals.gst,
        total: totals.total,
        paid: currentMode === "entry" ? totals.total : 0,
        balance: currentMode === "debit-note" ? totals.total : 0,
        status: currentMode === "entry" ? "paid" : (currentMode === "order" ? "sent" : "pending")
      };

      if (currentMode === "order") {
        payload.poNo = payload.billNo;
        payload.date = payload.billDate;
        payload.expectedDate = new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
        payload.totalAmount = payload.total;
      }

      const endpoint = currentMode === "order" ? "/api/purchase-orders" : "/api/purchase-entries";

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const json = await res.json();
      if (!json.success) throw new Error(json.error || "Failed to save");
      return json.data;
    },
    onSuccess: () => {
      toast.success(currentMode === "order" ? "Purchase Order Sent Successfully" : currentMode === "entry" ? "Purchase Inward Bill & IMEI Stock Logged" : "Debit Note Issued");
      queryClient.invalidateQueries({ queryKey: ["suppliers"] });
      queryClient.invalidateQueries({ queryKey: ["purchase-entries"] });
      queryClient.invalidateQueries({ queryKey: ["debit-notes"] });
      queryClient.invalidateQueries({ queryKey: ["purchase-orders"] });
      queryClient.invalidateQueries({ queryKey: ["items"] });
      onClose();
      // Reset form
      setForm({
        billNo: "",
        billDate: new Date().toISOString().split("T")[0],
        supplierName: "",
        supplierPhone: "",
        supplierId: "",
        linkedPoNo: "",
        items: [],
      });
      setSupplierLookupStatus("idle");
    },
    onError: (error: any) => {
      toast.error(error.message || "An error occurred");
    }
  });

  const handleSave = async () => {
    if (!form.supplierPhone || form.supplierPhone.length !== 10) {
      toast.error("Supplier mobile number (10 digits) is mandatory.");
      return;
    }
    if (!form.supplierName) {
      toast.error("Please enter or select a supplier name");
      return;
    }

    // MANDATORY PO CHECK FOR PURCHASE ENTRY
    if (currentMode === "entry") {
      if (!form.linkedPoNo) {
        toast.error("Please select and link an approved Purchase Order first.");
        return;
      }
    }

    if (form.items.length === 0) {
      toast.error("Please add or load at least one product item");
      return;
    }

    const hasIncompleteItem = form.items.some(i => !i.itemId || i.quantity <= 0);
    if (hasIncompleteItem) {
      toast.error("Please select products and ensure quantity > 0");
      return;
    }

    // MANDATORY IMEI / SERIAL NUMBER VALIDATION FOR PURCHASE ENTRY
    if (currentMode === "entry") {
      for (const item of form.items) {
        const serials = item.serialNumbers || [];
        if (serials.length !== item.quantity) {
          toast.error(`Please enter all ${item.quantity} IMEI / Serial numbers for ${item.name}`);
          return;
        }
        for (let i = 0; i < serials.length; i++) {
          if (!serials[i] || !serials[i].trim()) {
            toast.error(`Unit #${i + 1} IMEI / Serial number is missing for "${item.name}"`);
            return;
          }
        }
      }

      // Check duplicate serial numbers within the entry
      const allSerials = form.items.flatMap(i => (i.serialNumbers || []).map(s => s.trim().toUpperCase()));
      const uniqueSerials = new Set(allSerials);
      if (uniqueSerials.size !== allSerials.length) {
        toast.error("Duplicate IMEI / Serial numbers detected. Every unit must have a unique identifier.");
        return;
      }
    }

    // Auto-create new supplier in Master Suppliers
    if (form.supplierPhone && form.supplierName) {
      try {
        const newSupPayload = {
          name: form.supplierName,
          phone: form.supplierPhone,
          status: "active",
          address: {
            line1: "Commercial Trade Hub / Store Outlet",
            city: "Mumbai",
            state: "Maharashtra",
            pincode: "400001",
            country: "India",
          }
        };
        const supRes = await fetch("/api/suppliers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newSupPayload)
        });
        const supJson = await supRes.json();
        if (supJson.success && supJson.data?._id) {
          form.supplierId = supJson.data._id;
          queryClient.invalidateQueries({ queryKey: ["suppliers"] });
        }
      } catch (err) {
        console.error("Auto-create supplier failed:", err);
      }
    }

    saveMutation.mutate();
  };

  const isDebit = currentMode === "debit-note";
  const isOrder = currentMode === "order";
  const isEntry = currentMode === "entry";

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-5xl p-0 overflow-hidden bg-slate-50 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className={`p-6 text-white flex items-center justify-between shrink-0 ${isDebit ? 'bg-gradient-to-r from-red-950 via-red-900 to-red-950' : (isOrder ? 'bg-gradient-to-r from-amber-900 via-amber-800 to-amber-900' : 'bg-gradient-to-r from-[#1B2537] via-[#2C3E5A] to-[#1B2537]')}`}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center backdrop-blur-md border border-white/20">
              {isDebit ? <FileMinus className="w-6 h-6 text-red-400" /> : (isOrder ? <ShoppingBag className="w-6 h-6 text-amber-400" /> : <ClipboardList className="w-6 h-6 text-[#76C043]" />)}
            </div>
            <div>
              <DialogTitle className="text-xl font-bold tracking-tight">
                {isDebit ? "Issue Debit Note (Purchase Return)" : (isOrder ? "Create Purchase Order" : "Record Purchase Inward Entry")}
              </DialogTitle>
              <DialogDescription className={`text-xs mt-0.5 ${isDebit ? 'text-red-200' : (isOrder ? 'text-amber-200' : 'text-slate-300')}`}>
                {isDebit 
                  ? "Record returns to supplier and adjust payables" 
                  : (isOrder 
                    ? "Send formal restocking purchase order to supplier" 
                    : "Link approved Purchase Order, log incoming inventory & record unit IMEI serial numbers")}
              </DialogDescription>
            </div>
          </div>

          {/* Mode Switcher pill if needed */}
          {isEntry && (
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setCurrentMode("order");
                  setForm(prev => ({ ...prev, linkedPoNo: "", items: [] }));
                }}
                className="bg-white/10 border-white/20 text-white hover:bg-white/20 text-xs h-8"
              >
                <ShoppingBag className="w-3.5 h-3.5 mr-1.5 text-amber-300" /> Create PO First
              </Button>
            </div>
          )}
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Supplier Details */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
            <h4 className="text-sm font-semibold text-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-2">1. Supplier & Voucher Details</span>
              {isEntry && (
                <span className="text-[11px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  * PO Linkage & Unit IMEI Required
                </span>
              )}
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600">{isOrder ? "Purchase Order No." : "Bill / Inward No."}</Label>
                <Input
                  value={form.billNo}
                  onChange={(e) => setForm({ ...form, billNo: e.target.value })}
                  className="bg-slate-50 font-mono text-sm font-bold text-[#3F63AD]"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600">Voucher Date</Label>
                <Input
                  type="date"
                  value={form.billDate}
                  onChange={(e) => setForm({ ...form, billDate: e.target.value })}
                  className="bg-slate-50 text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-[#3F63AD]" /> Supplier Mobile Number *
                </Label>
                <div className="relative">
                  <Input
                    type="text"
                    maxLength={10}
                    placeholder="Enter 10-digit mobile"
                    value={form.supplierPhone}
                    onChange={(e) => handleSupplierPhoneLookup(e.target.value)}
                    className={cn(
                      "bg-slate-50 font-mono text-base tracking-wider pr-10",
                      supplierLookupStatus === "existing" && "border-emerald-400 bg-emerald-50/50 ring-2 ring-emerald-100",
                      supplierLookupStatus === "new" && "border-amber-400 bg-amber-50/50 ring-2 ring-amber-100"
                    )}
                    autoFocus
                  />
                  {supplierLookupStatus === "existing" && (
                    <span className="absolute right-2 top-1/2 -translate-y-1/2"><UserCheck className="w-4 h-4 text-emerald-600" /></span>
                  )}
                  {supplierLookupStatus === "new" && (
                    <span className="absolute right-2 top-1/2 -translate-y-1/2"><UserPlus className="w-4 h-4 text-amber-600" /></span>
                  )}
                </div>
              </div>

              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-xs text-slate-600">Supplier Name *</Label>
                <Input
                  placeholder="Enter or select supplier name"
                  value={form.supplierName}
                  onChange={(e) => setForm({ ...form, supplierName: e.target.value })}
                  className={cn(
                    "bg-slate-50 text-sm font-semibold",
                    supplierLookupStatus === "existing" && "bg-emerald-50/30"
                  )}
                />
              </div>

              {/* Supplier Dropdown Quick Pick */}
              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600">Existing Supplier Quick Pick</Label>
                <Select value={form.supplierName} onValueChange={handleSupplierSelect}>
                  <SelectTrigger className="bg-slate-50 text-sm">
                    <SelectValue placeholder="Choose Supplier..." />
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers.map((s: any) => (
                      <SelectItem key={s._id} value={s.name}>{s.name} ({s.phone || "No Phone"})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* ─── MANDATORY LINK PURCHASE ORDER SECTION (FOR ENTRY MODE) ──── */}
            {isEntry && (
              <div className="mt-4 pt-4 border-t border-slate-100">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-2">
                  <Label className="text-xs font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide">
                    <Barcode className="w-4 h-4 text-[#3F63AD]" /> 2. Link Approved Purchase Order (Mandatory) *
                  </Label>

                  {form.supplierName && supplierPendingPOs.length > 0 && (
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {supplierPendingPOs.length} active PO(s) available
                    </span>
                  )}
                </div>

                {!form.supplierName ? (
                  <div className="bg-slate-100/80 border border-slate-200 p-4 rounded-xl text-xs text-slate-500 flex items-center gap-2.5">
                    <AlertCircle className="w-4 h-4 text-slate-400 shrink-0" />
                    <span>Please enter or select a Supplier above to check available Purchase Orders.</span>
                  </div>
                ) : supplierPendingPOs.length === 0 ? (
                  // NO PO EXISTS FOR THIS SUPPLIER - SHOW EXPLICIT ENGLISH WARNING & CREATE PO BUTTON
                  <div className="bg-amber-50/90 border-2 border-amber-200 p-5 rounded-xl space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-amber-100 rounded-lg text-amber-800 shrink-0 mt-0.5">
                        <ShieldAlert className="w-5 h-5" />
                      </div>
                      <div>
                        <h5 className="text-sm font-bold text-amber-950">No Active Purchase Order Found</h5>
                        <p className="text-xs text-amber-800 mt-1 leading-relaxed">
                          You do not have any pending or active Purchase Orders for <span className="font-bold underline">{form.supplierName}</span>. 
                          In ValuePlus ERP, a Purchase Inward Entry must be linked to an approved Purchase Order to track ordered stock and agreed pricing.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-amber-200">
                      <Button 
                        size="sm" 
                        onClick={() => {
                          setCurrentMode("order");
                          setForm(prev => ({ ...prev, linkedPoNo: "", items: [] }));
                          toast.info("Switched to Purchase Order mode. Create and send PO first.");
                        }}
                        className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs h-8 shadow-sm"
                      >
                        <Plus className="w-3.5 h-3.5 mr-1" /> Create Purchase Order for {form.supplierName}
                      </Button>
                    </div>
                  </div>
                ) : (
                  // POs ARE AVAILABLE - SHOW SELECTION DROPDOWN
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Select value={form.linkedPoNo} onValueChange={handleLoadPO}>
                        <SelectTrigger className="bg-slate-50 text-sm flex-1 border-slate-300 h-10">
                          <SelectValue placeholder="-- Select Approved Purchase Order to Auto-Fill Items --" />
                        </SelectTrigger>
                        <SelectContent>
                          {supplierPendingPOs.map((po: any) => (
                            <SelectItem key={po.poNo} value={po.poNo}>
                              <span className="font-bold font-mono text-[#3F63AD]">{po.poNo}</span> — {po.items?.length || 0} Products ({formatCurrency(po.totalAmount)})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      {form.linkedPoNo && (
                        <Badge variant="success" className="h-10 px-3 flex items-center gap-1.5 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5" /> PO Linked: {form.linkedPoNo}
                        </Badge>
                      )}
                    </div>

                    {!form.linkedPoNo && (
                      <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg text-xs text-blue-800 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>First select an approved Purchase Order from the dropdown above to load products, quantities, and rates.</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Line Items & IMEI/Serial Numbers */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-semibold text-slate-800 flex items-center gap-2">
                  {isEntry ? "3. Products & Unit IMEI / Serial Numbers" : "2. Product Line Items"}
                </h4>
                {isEntry && form.items.length > 0 && (
                  <p className="text-xs text-slate-500 mt-0.5">
                    Enter unique IMEI / Serial numbers for every received physical unit.
                  </p>
                )}
              </div>

              {!isEntry && (
                <Button size="sm" variant="outline" onClick={addLineItem} className="h-8 border-dashed">
                  <Plus className="w-4 h-4 mr-1" /> Add Product
                </Button>
              )}
            </div>

            {isEntry && !form.linkedPoNo ? (
              <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center space-y-2 bg-slate-50/50">
                <Barcode className="w-8 h-8 text-slate-400 mx-auto" />
                <h5 className="text-sm font-bold text-slate-700">No Purchase Order Linked</h5>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Please link a Purchase Order in step 2 above. All ordered electronics, quantities, and inward IMEI slots will load automatically.
                </p>
              </div>
            ) : form.items.length === 0 ? (
              <div className="border border-dashed rounded-lg p-8 text-center text-muted-foreground text-sm">
                No items added. Click "Add Product" to begin.
              </div>
            ) : (
              <div className="space-y-4">
                {form.items.map((item, index) => {
                  const amount = item.quantity * item.rate;
                  const enteredSerialsCount = (item.serialNumbers || []).filter(s => s && s.trim()).length;
                  const allSerialsDone = enteredSerialsCount === item.quantity && item.quantity > 0;

                  return (
                    <div key={item.id} className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm transition-all hover:border-slate-300">
                      {/* Item Header Row */}
                      <div className="p-4 bg-slate-50/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
                          <span className="w-6 h-6 rounded-full bg-slate-200 text-slate-700 text-xs font-bold flex items-center justify-center">
                            {index + 1}
                          </span>

                          <div className="flex-1">
                            {isEntry ? (
                              <div>
                                <p className="text-sm font-bold text-slate-900">{item.name}</p>
                                <p className="text-xs text-slate-500">Agreed Rate: {formatCurrency(item.rate)} + {item.gstRate}% GST</p>
                              </div>
                            ) : (
                              <Select value={item.itemId} onValueChange={(val) => handleItemSelect(item.id, val)}>
                                <SelectTrigger className="h-9 text-xs bg-white border-slate-300">
                                  <SelectValue placeholder="Search product catalog..." />
                                </SelectTrigger>
                                <SelectContent>
                                  {catalogItems.map((c: any) => (
                                    <SelectItem key={c._id} value={c._id}>{c.name} — {formatCurrency(c.purchasePrice || 0)}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            )}
                          </div>
                        </div>

                        {/* Quantity & Rate */}
                        <div className="flex items-center gap-4">
                          <div className="text-center">
                            <Label className="text-[10px] text-slate-500 font-bold uppercase block">Quantity</Label>
                            <Input
                              type="number"
                              min={1}
                              value={item.quantity}
                              disabled={isEntry}
                              onChange={(e) => updateLineItem(item.id, "quantity", Math.max(1, Number(e.target.value)))}
                              className="h-8 w-20 text-xs text-center font-bold bg-white"
                            />
                          </div>

                          <div className="text-center">
                            <Label className="text-[10px] text-slate-500 font-bold uppercase block">Rate (₹)</Label>
                            <Input
                              type="number"
                              min={0}
                              value={item.rate}
                              disabled={isEntry}
                              onChange={(e) => updateLineItem(item.id, "rate", Math.max(0, Number(e.target.value)))}
                              className="h-8 w-24 text-xs text-right font-bold bg-white"
                            />
                          </div>

                          <div className="text-center">
                            <Label className="text-[10px] text-slate-500 font-bold uppercase block">GST %</Label>
                            <span className="text-xs font-semibold text-slate-700 block mt-1.5">{item.gstRate}%</span>
                          </div>

                          <div className="text-right min-w-[100px]">
                            <Label className="text-[10px] text-slate-500 font-bold uppercase block">Item Total</Label>
                            <span className="text-sm font-black text-slate-900 block mt-1">{formatCurrency(amount)}</span>
                          </div>

                          {!isEntry && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-slate-400 hover:text-red-600 hover:bg-red-50 ml-1"
                              onClick={() => removeLineItem(item.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>

                      {/* Unit-by-Unit IMEI / Serial Number Input Grid (FOR ENTRY MODE) */}
                      {isEntry && (
                        <div className="p-4 bg-slate-50/30">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <Barcode className="w-4 h-4 text-[#3F63AD]" />
                              <span className="text-xs font-bold text-slate-800">
                                Unit IMEI / Serial Numbers
                              </span>
                              <Badge variant={allSerialsDone ? "success" : "warning"} className="text-[10px] ml-1">
                                {enteredSerialsCount} / {item.quantity} Recorded
                              </Badge>
                            </div>

                            <button 
                              type="button" 
                              onClick={() => toggleSerialsDisplay(item.id)}
                              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-medium"
                            >
                              {item.showSerials ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                              {item.showSerials ? "Collapse" : "Expand"}
                            </button>
                          </div>

                          {item.showSerials && (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                              {Array.from({ length: item.quantity }).map((_, unitIdx) => {
                                const currentSerial = item.serialNumbers?.[unitIdx] || "";
                                const isValid = currentSerial.trim().length > 0;

                                return (
                                  <div key={unitIdx} className="space-y-1 bg-white p-2.5 rounded-lg border border-slate-200">
                                    <div className="flex items-center justify-between text-[11px]">
                                      <span className="font-semibold text-slate-600">Unit #{unitIdx + 1} Serial / IMEI</span>
                                      {isValid ? (
                                        <span className="text-emerald-600 font-bold flex items-center gap-0.5 text-[10px]">
                                          <CheckCircle2 className="w-3 h-3" /> Valid
                                        </span>
                                      ) : (
                                        <span className="text-amber-600 font-bold text-[10px]">Required *</span>
                                      )}
                                    </div>
                                    <Input
                                      placeholder={`Scan or type Unit #${unitIdx + 1} IMEI / Serial`}
                                      value={currentSerial}
                                      onChange={(e) => updateSerialNumber(item.id, unitIdx, e.target.value.toUpperCase())}
                                      className={cn(
                                        "h-8 text-xs font-mono tracking-wider bg-slate-50",
                                        isValid ? "border-emerald-300 bg-emerald-50/20" : "border-amber-300 bg-amber-50/20"
                                      )}
                                    />
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer & Totals */}
        <div className="bg-slate-100 p-6 rounded-b-2xl border-t border-slate-200 shrink-0">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-1">
              <div className="flex items-center gap-4 text-sm text-slate-600">
                <span>Taxable Subtotal: <strong className="text-slate-800">{formatCurrency(totals.subtotal)}</strong></span>
                <span>GST Tax: <strong className="text-slate-800">{formatCurrency(totals.gst)}</strong></span>
              </div>
              <div className="text-xl font-black text-slate-900">
                Net Voucher Total: <span className="text-[#3F63AD] font-mono">{formatCurrency(totals.total)}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
              <Button variant="outline" onClick={onClose} className="w-full md:w-auto px-6">
                Cancel
              </Button>
              <Button 
                onClick={handleSave} 
                disabled={saveMutation.isPending}
                className={`w-full md:w-auto px-8 font-bold shadow-lg ${isDebit ? 'bg-red-600 hover:bg-red-700 shadow-red-600/20' : (isOrder ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-600/20' : 'bg-[#3F63AD] hover:bg-[#2E4F95] shadow-[#3F63AD]/20')}`}
              >
                {saveMutation.isPending ? "Recording..." : (isDebit ? "Save Debit Note" : (isOrder ? "Send Purchase Order" : "Record Purchase Inward & Stock"))}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
